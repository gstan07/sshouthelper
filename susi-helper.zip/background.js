


 var susi_helper = {
 	getCurrentUrl : function(){
 		return window.location.toString();
 	},
 	createLocaleSelector:function(){
 		var locales = ["bg_BG","cs_CZ","da_DK","de_DE","en_AE","en_GB","en_IL","en_XM","es_ES","es_LA","es_MX","es_NA","et_EE","fi_FI","fr_CA","fr_FR","fr_MA","fr_XM","hr_HR","hu_HU","it_IT","ja_JP","ko_KR","lt_LT","lv_LV","nb_NO","nl_NL","pl_PL","pt_BR","ro_RO","ru_RU","sk_SK","sl_SL","sr_RS","sr_SP","sv_SE","tr_TR","uk_UA","zh_CN","zh_TW"];
 		var selector = $("<select class='susi_langselector'/>");
 		selector.append("<option>en</option>");
 		selector.css({
 			"position":"fixed",
 			"right":20
 		});
 		if($("#idp-tag").size()>0){
 			selector.css({
 				"top":40,
 			});
 		}else{
 			selector.css({
 				"top":10,
 			});
 		}
 		var current_locale =susi_helper.getQueryVariable("locale")
 		$.each(locales,function(k,v){
 			var option = $("<option value='"+v+"'>"+v+"</option>");
 			if(v==current_locale){
 				option.attr("selected","selected");	
 			}
 			option.appendTo(selector);
 		})
 		return selector;
 	},
 	getQueryVariable: function(variable) {
    	var query = window.location.search.substring(1);
	    var vars = query.split('&');
	    for (var i = 0; i < vars.length; i++) {
	        var pair = vars[i].split('=');
	        if (decodeURIComponent(pair[0]) == variable) {
	            return decodeURIComponent(pair[1]);
	        }
	    }
    	console.log('Query variable %s not found', variable);
	},
 	goToUrl:function(url){
 		// alert(url);
 		window.location.href = url;
 	},
 	createOptionsScreen:function(){
 		 //create elements
		 var lang_selector = susi_helper.createLocaleSelector();
		 lang_selector.on("change",function(){
		 	//alert($(this).val())
		 	//(locale=(.[A-Za-z0-9,_]))
		 	var current_url = susi_helper.getCurrentUrl();
		 	var exp = new RegExp("(locale=(.[A-Za-z0-9,_]))", "gm");
		 	var new_url = current_url.replace(exp,"locale="+$(this).val()+"&");
		 	susi_helper.goToUrl(new_url);
		 	//alert("aaa");
		 });

		 lang_selector.appendTo("body");
	}
 }
susi_helper.createOptionsScreen();
 // alert(susi_helper.getCurrentUrl());